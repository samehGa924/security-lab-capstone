# Evidence

Add only evidence generated from authorized local testing:

- Nmap output screenshots
- Wireshark screenshots
- OWASP Juice Shop PoC screenshots
- Sanitized logs

Do not upload passwords, API keys, private keys, tokens, or sensitive personal data.
