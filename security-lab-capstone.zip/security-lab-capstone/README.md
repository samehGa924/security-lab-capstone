# Security Lab Capstone – VAPT

Enterprise-style cybersecurity capstone combining:

- Network reconnaissance and port scanning
- Nmap service enumeration
- OWASP Juice Shop assessment workflow
- OWASP vulnerability mapping
- CVSS-oriented risk assessment
- Defensive remediation guidance
- Cryptography and secure authentication utilities

## Scope

All practical testing was conducted only against authorized local training environments.

## Repository Structure

```text
security-lab-capstone/
├── README.md
├── docs/
│   └── remediation-roadmap.md
├── reports/
│   └── Enterprise_VAPT_Capstone_Report_Sameh.pdf
└── evidence/
    └── README.md
```

## Disclaimer

This repository is for authorized educational cybersecurity testing only. It does not contain credentials, private keys, or production target information.
